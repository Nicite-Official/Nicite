# Welcome to Nicite!
## How to Install the Nicite Compiler
To use .nic files, you first need to add the Nicite compiler to your PATH. This guide will show you how to do this.
### On macOS:
To install Nicite successfully, you will want to execute these commands:

```cd ~/Downloads```

and

```sudo cp nic /usr/local/bin/nic```

This command will ask you for your password, so please enter your password to continue.

***This installs Nicite on your macOS machine.***
### On Windows:
The Windows version needed is unspecified so far, so use Windows 11 if you can.

To install Nicite successfully, you will want to execute these commands:

```cd Downloads```

and

```setx PATH "%PATH%;C:\Users\<EnterUsername>\Downloads\nic```

You can check your username by opening File Explorer, then by clicking on C:\Users

***This installs Nicite on your Windows machine.***
### On Linux:
To install Nicite successfully, you will want to execute these commands:

```echo $SHELL```

This command checks which shell you are using. Make sure to run this next command before continuing:

```sudo apt install nano```

This command will ask you for your password, so please enter your password to continue.
#### On the ```bash``` shell version:
Execute the command:

```nano ~/.bashrc```

Scroll to the bottom and paste the line that says your PATH directory. Enter this command next:

```export PATH="$PATH:/path/to/nicite"```

After you use this command, press ```Ctrl + 0```, then press ```Enter``` to save it. Press ```Ctrl + X``` to exit Nano.
#### On the ```zsh``` shell version:
Execute the command:

```nano ~/.zshrc```

Scroll to the bottom and paste the line that says your PATH directory. Enter this command next:

```export PATH="$PATH:/path/to/nicite"```

***This installs Nicite on your Linux machine.***
## How to Use the Nicite Compiler
Using the Nicite Compiler is a very simple process. To run .nic files, execute the command:

```nic yourfile.nic```
# Changelog
This is v1.0 of Nicite! There are currently no changes added.